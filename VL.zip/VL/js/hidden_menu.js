function hidden() {
    const hiddenElement = document.getElementById('menu');
      hiddenElement.style.display = 'none';
  }
  